package com.ivanloy.nutricards.gameelements

class FoodCard(
        val type : FoodCardTypes = FoodCardTypes.BLANK
)