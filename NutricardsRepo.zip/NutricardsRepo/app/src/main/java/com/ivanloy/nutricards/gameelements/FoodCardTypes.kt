package com.ivanloy.nutricards.gameelements

enum class FoodCardTypes {
    BLANK, SWEET, MEAT, FISH, FORK, DAIRY, FRUIT, VEGETABLE, PASTA, CEREAL
}
